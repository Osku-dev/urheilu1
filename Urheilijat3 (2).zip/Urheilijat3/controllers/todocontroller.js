//var data = [{item:'get milk'}, {item:'walk dog'},{item:'kick some coding ass'}]

const bodyParser = require('body-parser');



var mongoose = require('mongoose');
//var dbUrl = "mongodb://mongodb-server:27017/todo";
var dbUrl = "mongodb://localhost:27017/athletics";
mongoose.connect(dbUrl, {
    useUnifiedTopology: true,
    useNewUrlParser: true,
    })
    .then(() => console.log('DB Connected!'))
    .catch(err => {
    console.log('DB Connection Error: ${err.message}');
    });

var athleticsSchema = new mongoose.Schema({
    item: String
});

var Athletics = mongoose.model('Athletics',athleticsSchema);
/*var itemOne = Athletics({item:  "firstname", "testi", "lastname": "Helander","nickname":"Hela", 
"dateofbirth":"2016-11-07T20:22:48.743Z","weight":90, "img": 
"yleisurheilu.fi/wp-content/uploads/2019/02/Oliver-Helander.jpg", "sports": "javelin", "stats": "sm 2018/1"})
.save(function(err){
    if(err) throw err;
    console.log('item saved');
}); */

var urlencodedParser = bodyParser.urlencoded({extended:false});

module.exports = function(app) {

    app.get('/athletics', function(req,res){
        Athletics.find({}, function(err,data){
            if(err) throw err;
            res.render('athletics', {athletics: data});
        });
        
    });

    app.post('/athletics', urlencodedParser, function(req,res){
        var newAthletics=athletics(req.body).save(function(err,data){
            if(err) throw err;
            res.json(data);
        });

    });


    app.delete('/athletics/:item', function(req,res){
        
        Athletics.find({item:req.params.item.replace(/\-/g, " ")}).deleteOne(function(err,data){
            if(err) throw err;
            res.json(data);
        });
      
    });
};