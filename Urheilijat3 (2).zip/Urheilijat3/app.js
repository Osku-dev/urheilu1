var express = require('express');

var morgan = require('morgan')

var todocontroller = require('./controllers/todocontroller.js');

var app = express();

app.use(morgan('combined'))

app.set('view engine', 'ejs');

app.use(express.static('./public'));

todocontroller(app);

app.listen(3000);

console.log('kuunnellaan porttia 3000');