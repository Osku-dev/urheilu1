var onkoLaivaTaulukossa = false;

// Promise
var toimiiko = new Promise(
    generateRandomBoard() (resolve, reject) {
        if (onkoLaivaTaulukossa) {
            var kylla = {
              console.log
            };
            resolve(phone); // fulfilled
        } else {
            var reason = new Error('mom is not happy');
            reject(reason); // reject
        }

    }
);